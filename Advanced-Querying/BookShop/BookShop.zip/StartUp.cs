﻿namespace BookShop
{
    using System;
    using System.Linq;
    using System.Text;

    using BookShop.Models.Enums;

    using Data;

    using Initializer;

    using Microsoft.EntityFrameworkCore;

    public class StartUp
    {
        public static void Main()
        {
            var context = new BookShopContext();

            // DbInitializer.ResetDatabase(context);
        

            Console.WriteLine(GetGoldenBooks(context));
        }

        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            var restriction = Enum.Parse<AgeRestriction>(command, true);

            var booksTitle = context.Books.Where(x => x.AgeRestriction == restriction).Select(x => x.Title)
                .OrderBy(x => x).AsNoTracking().ToArray();

            return string.Join(Environment.NewLine, booksTitle);
        }

        public static string GetGoldenBooks(BookShopContext context)
        {
            var goldenBooks = context.Books.
                Where(x => x.Copies < 5000 && x.EditionType==EditionType.Gold).
                Select(x => new
                                {
                                    x.BookId, x.Title
                                })
                .OrderBy
                    (x => x.BookId).
                ToArray();

            StringBuilder info = new StringBuilder();

            foreach (var book in goldenBooks)
            {
                info.AppendLine(book.Title);
            }

            return info.ToString().Trim();
        }
    }
}